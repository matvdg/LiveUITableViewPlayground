import PlaygroundSupport
import UIKit

enum iPhone {
    case iPhone_4S
    case iPhone_5
    case iPhone_5S
    case iPhone_5C
    case iPhone_SE
    case iPhone_6
    case iPhone_6S
    case iPhone_7
    case iPhone_6Plus
    case iPhone_6SPlus
    case iPhone_7Plus
}

var iPhones: [iPhone: CGRect] = [
.iPhone_4S: CGRect(x: 0, y: 0, width: 320, height: 480),
.iPhone_5: CGRect(x: 0, y: 0, width: 320, height: 568),
.iPhone_5S: CGRect(x: 0, y: 0, width: 320, height: 568),
.iPhone_5C: CGRect(x: 0, y: 0, width: 320, height: 568),
.iPhone_SE: CGRect(x: 0, y: 0, width: 320, height: 568),
.iPhone_6: CGRect(x: 0, y: 0, width: 375, height: 667),
.iPhone_6S: CGRect(x: 0, y: 0, width: 375, height: 667),
.iPhone_7: CGRect(x: 0, y: 0, width: 375, height: 667),
.iPhone_6Plus: CGRect(x: 0, y: 0, width: 414, height: 736),
.iPhone_6SPlus: CGRect(x: 0, y: 0, width: 414, height: 736),
.iPhone_7Plus: CGRect(x: 0, y: 0, width: 414, height: 736),
]

extension CGRect {
    var landscape: CGRect {
        return CGRect(x: 0, y: 0, width: self.height, height: self.width)
    }
}


/*
 
 CODE HERE
 
 */


struct Pokemon {
    let id: UInt
    let name: String
}

class PokedexViewController: UITableViewController {
    let pokemons: [Pokemon] = [
        Pokemon(id: 1, name: "Bulbizarre"),
        Pokemon(id: 2, name: "Pikachu"),
        Pokemon(id: 3, name: "Carapuce"),
        Pokemon(id: 4, name: "Dracaufeu"),
        Pokemon(id: 5, name: "Herbizarre"),
        Pokemon(id: 6, name: "Papillusion"),
        Pokemon(id: 7, name: "Reptincel"),
        Pokemon(id: 8, name: "Salamèche"),
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pokemons.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "PokemonTableViewCell")
        let pokemon = pokemons[indexPath.row]
        cell.textLabel?.text = pokemon.name
        cell.accessoryType = .disclosureIndicator
        cell.imageView?.contentMode = .scaleAspectFit
        cell.imageView?.image = UIImage(named: pokemon.name)
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let pokemon = pokemons[indexPath.row]
        let viewController = PokemonViewController(frame: tableView.frame, pokemon: pokemon)
        
        navigationController?.pushViewController(viewController, animated: true)
    }
}

class PokemonViewController: UIViewController {
    private let pokemon: Pokemon
    
    init(frame: CGRect, pokemon: Pokemon) {
        self.pokemon = pokemon
        super.init(nibName: nil, bundle: nil)
        
        self.title = self.pokemon.name
        self.view = UIView(frame: frame)
        self.view.backgroundColor = .white
        let imageView = UIImageView(frame: self.view.frame)
        imageView.contentMode = .scaleAspectFit
        imageView.image = UIImage(named: self.pokemon.name)
        self.view.addSubview(imageView)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

let rootViewController = PokedexViewController()
rootViewController.title = "Pokedex"

let navigationController = UINavigationController(rootViewController: rootViewController)
navigationController.view.frame = iPhones[.iPhone_6S]!
PlaygroundPage.current.liveView = navigationController.view